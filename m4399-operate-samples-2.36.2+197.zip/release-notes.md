## 运营SDK v2.36.2 更新事项

### 功能
- 不再强制开发者申请“发送短信”权限
- 处理延迟优惠券列表失败请求
- 添加应用是否在前台健壮性判断

### 接入方式

- AndroidManifest.xml:
    - 已删除/简化非必要权限
    - 已删除/简化部分activity注册
- java 接口:
    - 删除mOpeCenter.destroy()接口
- 目录结构:
    - 已改成Android studio project形式
    - 简化混淆文件