## 运营SDK v2.36.1 更新事项

### 功能
- 优化部分机型QQ充值订单客户端状态错误
- 修复获取旧版本数据类型异常问题
- 修复偶现getRunningAppProcesses空指针问题
- 修复偶现创建横幅BadTokenException问题

### 接入方式

- AndroidManifest.xml:
    - 已删除/简化非必要权限
    - 已删除/简化部分activity注册
- java 接口:
    - 删除mOpeCenter.destroy()接口
- 目录结构:
    - 已改成Android studio project形式
    - 简化混淆文件