## 运营SDK v2.36.0 更新事项

### 功能
- 新增登录防刷功能
- 新增通用优惠券
- 新增微信、QQ支付渠道订单状态查询
- UI风格改版
- 重构登录、充值、个人中心等功能
- 修复猜你喜欢跳转游戏盒问题
- 新增优惠券抢券功能

### 接入方式

- AndroidManifest.xml:
    - 已删除/简化非必要权限
    - 已删除/简化部分activity注册
- java 接口:
    - 删除mOpeCenter.destroy()接口
- 目录结构:
    - 已改成Android studio project形式
    - 简化混淆文件