package cn.m4399.game;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import java.io.InputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

/**
 * Created by 4399-1126 on 2017/7/11.
 */

public class PingActivity extends Activity {
    TextView info=null;
    int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.info = (TextView) findViewById(R.id.info);
        RunHandler();
    }

    public void startPing(String ip) {
        try {
            Process p = Runtime.getRuntime().exec("ping -c 1 -w 100 " + ip,null,null);//-c 1 说明只发送一次数据包就停止 -w: 表示deadline, time out的时间，单位为秒，100为100秒。
            int status = p.waitFor();
            InputStream input = p.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(input));
            StringBuffer buffer = new StringBuffer();
            String line = "";
            while ((line = in.readLine()) != null){
                buffer.append(line);
            }
            String pingValue=buffer.substring(buffer.indexOf("time=")+1,buffer.indexOf("ms"));

            if (status == 0) {
                i++;
                info.setText("Ping www.baidu.com 进行中... " + i);
            } else {
                info.setText("Fail: IP addr not reachable");
            }
        } catch (IOException e) {
            info.setText("Fail: IOException"+e.getMessage());
        } catch (InterruptedException e) {
            info.setText("Fail: InterruptedException"+e.getMessage());
        }
    }

    @SuppressLint("HandlerLeak")
    private void RunHandler(){
        // 实时更新UI
        final Handler mHandler = new Handler() {
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                startPing("www.baidu.com");
            }
        };

        Runnable mRunnable = new Runnable() {
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(1000);
                        mHandler.sendMessage(mHandler.obtainMessage());
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        };
        new Thread(mRunnable).start();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
     //   getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
       /* if (id == R.id.action_settings) {
            return true;
        }*/
        return super.onOptionsItemSelected(item);
    }
}
