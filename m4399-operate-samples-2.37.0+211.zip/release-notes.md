## 运营SDK v2.37.0 更新事项

### 功能
- 新增防沉迷未通过公安部验证弹窗文案提示
- 不强制做SDK申请权限
- 替换闪屏图片
- 修复个人中心页面圆角兼容性问题
- 修复后台收集到的bug

### 接入方式
以下接入方式的改动是v2.37针对v2.36之前版本的变动，如游戏方已之前接入的SDK版本是v2.36的话，只需要关注AndroidManifest.xml中的简化部分activity注册与新增Android 11兼容
- AndroidManifest.xml:
    - 已删除/简化非必要权限
    - 已删除/简化部分activity注册
    - 新增Android 11兼容，声明所要进行交互的应用包名，主要用于外部授权登录
- java 接口:
    - 删除mOpeCenter.destroy()接口
- 目录结构:
    - 已改成Android studio project形式
    - 简化混淆文件