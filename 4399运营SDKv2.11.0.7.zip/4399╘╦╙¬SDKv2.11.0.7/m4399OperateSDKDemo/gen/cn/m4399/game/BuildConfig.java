/** Automatically generated file. DO NOT MODIFY */
package cn.m4399.game;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}